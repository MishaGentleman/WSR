var express = require('express');
var app = express();
app.get('/', function(req, res) {
  res.sendfile('int.html');
});
app.get('/', function(req, res) {
  res.sendfile('lk.html');
});
app.listen(8080);
console.log('Сервер стартовал!');